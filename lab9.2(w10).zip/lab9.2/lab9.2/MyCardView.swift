//
//  MyCardView.swift
//  lab9.2
//
//  Created by C410 on 2017-03-09.
//  Copyright © 2017 GBC. All rights reserved.
//

import UIKit

@IBDesignable
class MyCardView: UIView {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var lable: UILabel!
    var frontView: UIImageView!
    var backView: UIImageView!
    
    var start = true
    
    @IBInspectable var frontImage: UIImage!{
    
        get{
            if frontView == nil{
                frontView = UIImageView(frame: CGRect(
                    x:0, y:0, width: self.frame.width, height: self.frame.height
                ))
                frontView.image = UIImage(named: "front")
            }
            return frontView.image
            
        }
        
        set(image){
            if frontView == nil{
                frontView = UIImageView(frame: CGRect(
                    x:0, y:0, width: self.frame.width, height: self.frame.height
                ))
            }
            
            frontView.image = image
        }
    }
    
    
    @IBInspectable var backImage: UIImage!{
        
        get{
            if backView == nil{
                backView = UIImageView(frame: CGRect(
                    x:0, y:0, width: self.frame.width, height: self.frame.height
                ))
                backView.image = UIImage(named: "back")
            }
            return backView.image
            
        }
        
        set(image){
            if backView == nil{
                backView = UIImageView(frame: CGRect(
                    x:0, y:0, width: self.frame.width, height: self.frame.height
                ))
            }
            
            backView.image = image
        }
    }

    
    var showBack = true

    func setup(){
    
        
        //frontView.image = frontImage

        let _ = frontImage
        let _ = backImage
        
        //addSubview(frontView)
        
        xibSetup()
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }
    
    var view:UIView!
    
    func xibSetup(){
        
        view = loadViewFromNib()
        view.frame = bounds
        view.autoresizingMask = self.autoresizingMask
    
        addSubview(view)
        
    }
    
    func loadViewFromNib()->UIView{
    
        let bundle = Bundle(for: type(of:self))
        
        let nib  = UINib(nibName: "MyCardView", bundle: bundle)
        
        let view = nib.instantiate(withOwner: self, options: nil)[0] as! UIView
        
        return view
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        
        if start{
            UIView.transition(from: imageView, to: backView, duration: 1, options: UIViewAnimationOptions.transitionFlipFromBottom,
                              completion: nil)
            
            start = false
            showBack = true
        }else{
        
        if showBack {
        UIView.transition(from: backView, to: frontView, duration: 1, options: UIViewAnimationOptions.transitionFlipFromRight,
            completion: nil)
        }else{
            UIView.transition(from: frontView, to: backView, duration: 1, options: UIViewAnimationOptions.transitionFlipFromLeft,
                              completion: nil)

        }
        
        showBack = !showBack
        
        }
    }
    
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
