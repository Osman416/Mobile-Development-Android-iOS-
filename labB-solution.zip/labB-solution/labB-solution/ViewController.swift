//
//  ViewController.swift
//  labB-solution
//
//  Created by C410 on 2017-02-23.
//  Copyright © 2017 GBC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inText: UITextField!
    @IBOutlet weak var outLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        outLabel.text=""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBOutlet weak var clear: UIButton!
    
    @IBAction func clickBtn(_ sender: UIButton) {
        
        if (outLabel.text?.isEmpty)! || outLabel.text==""{
            outLabel.text = inText.text!
        }
        outLabel.text = "\(outLabel.text!) \((sender.titleLabel?.text)!)"
        let cgc:CGColor = sender.backgroundColor!.cgColor
        let str = CIColor(cgColor: cgc).stringRepresentation
        print(str)
        
    }
    @IBAction func clearAll(_ sender: Any) {
        outLabel.text = ""
        inText.text=""
    }
}

