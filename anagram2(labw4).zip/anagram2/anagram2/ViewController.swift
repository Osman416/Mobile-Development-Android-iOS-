//
//  ViewController.swift
//  anagram2
//
//  Created by C410 on 2017-02-02.
//  Copyright © 2017 GBC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var pointsLabel: UILabel!
    
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var feedbackLabel: UILabel!
    
    @IBOutlet weak var answerText: UITextField!
    
    private var questionsDict = [String:String]()
    
    private var question:(String,String)? = nil
    
    private var points = 0 {
        
        didSet{
            pointsLabel.text = String(points)
        }
    }
    
    
    private func generate(){
    
        questionsDict["code"] = "doce"
        questionsDict["test"] = "stet"
        questionsDict["class"] = "slcas"
        questionsDict["setup"] = "upset"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        feedbackLabel.text = ""
        points = 0
        questionLabel.text = "Tap Start button"
        generate()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var isSubmitted = true
    
    @IBAction func submitClick(_ sender: UIButton) {
        
        if !isSubmitted {
            
            let a = answerText.text
            
            if a?.uppercased()==question?.0.uppercased(){
                //correct
                
                feedbackLabel.text = "Correct!"
                feedbackLabel.textColor = UIColor.green
                points+=1
                
            }else{
                //incorrect
                feedbackLabel.text = "Wrong!"
                feedbackLabel.textColor = UIColor.red

            }
            
            sender.setTitle("Next", for: .normal)
            isSubmitted = true
        }else{
            
            let keys = Array(questionsDict.keys)
            let idx = Int(arc4random_uniform(UInt32(questionsDict.count)))
            let k = keys[idx]
            let v = questionsDict[k]
            
            question = (k,v!)
            
            questionLabel.text = v!
            
            sender.setTitle("Submit", for: .normal)
            feedbackLabel.text = ""
            answerText.text = ""
            isSubmitted = false
        }
    }

    @IBAction func clearAnswer(_ sender: UITextField) {
        
        sender.text = ""
    }
}

