//
//  ViewController.swift
//  LabA-solution
//
//  Created by C410 on 2017-02-23.
//  Copyright © 2017 GBC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var label: UILabel!

    @IBOutlet var btns: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnClick(_ sender: UIButton) {
        
        label.text = "Selected color \((sender.titleLabel?.text)!)"
        
        
        for b in btns{
            b.layer.borderColor = UIColor.white.cgColor
        }
         sender.layer.borderColor = UIColor.black.cgColor
        sender.layer.borderWidth = 5;
        
        sender.clipsToBounds = true
    }

}

