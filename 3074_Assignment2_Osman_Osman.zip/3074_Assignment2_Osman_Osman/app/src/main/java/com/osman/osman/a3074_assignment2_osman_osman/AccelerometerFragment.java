package com.osman.osman.a3074_assignment2_osman_osman;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link AccelerometerFragment . OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link AccelerometerFragment# newInstance} factory method to
 * create an instance of this fragment.
 */
public class AccelerometerFragment extends Fragment {

    private SensorManager sensorManager; //create sensor manager
    private AccelerometerEventListener accelerometerListener; //create accelerometer event listener

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_accelerometer, container, false);

        sensorManager = (SensorManager)
                this.getActivity().getSystemService(Context.SENSOR_SERVICE);
        TextView textView = (TextView)view.findViewById(R.id.tv_accelerometer);
        accelerometerListener = new AccelerometerEventListener(textView, getActivity());
        sensorManager.registerListener(accelerometerListener, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);

        return view;
    }

    @Override
    public void onResume()
    {
        super.onResume();
        sensorManager.registerListener(accelerometerListener, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onPause()
    {
        super.onPause();
        sensorManager.unregisterListener(accelerometerListener);
    }
}
