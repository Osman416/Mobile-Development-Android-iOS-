package com.osman.osman.a3074_assignment2_osman_osman;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuItem;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.view.View;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;
import android.content.Context;

public class ShakeAlertActivity extends AppCompatActivity implements View.OnClickListener{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shake_alert);
    }

    //goes back when button is clicked
    @Override
    public void onClick(View v) {
        // finish();
        super.onBackPressed();
    }
}
