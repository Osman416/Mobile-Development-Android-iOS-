package com.osman.osman.a3074_assignment2_osman_osman;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v4.app.FragmentActivity;
import android.widget.TextView;

/**
 * Created by Osman on 2016-11-05.
 */

public class AccelerometerEventListener implements SensorEventListener {
    private final String defaultText = "Accelerometer: "; // default text displayed before accelerometer
    private final float accelCompare = 1.0f; // Size of change in the accelerometer that must be met before TextView updates
    private final float shakeThreshold = 800.0f;

    private TextView textView1; // TextView used to display accelerometer information
    private FragmentActivity activity1;
    private long lastUpdate = 0;
    private float X, Y, Z;

    public AccelerometerEventListener (TextView textView, FragmentActivity activity)
    {
        textView1 = textView;
        activity1 = activity;
    }

    public void onSensorChanged (SensorEvent event)
    {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
        {
            long currTime = System.currentTimeMillis();
            if (currTime - lastUpdate < 100)
                return;

            long timeDiff = (currTime - lastUpdate);
            lastUpdate = currTime;

            // x,y,z values
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            float speed = Math.abs(x + y + z - X - Y - Z) / timeDiff * 10000;
            if (speed > shakeThreshold)
            {
                Intent intent = new Intent(activity1, ShakeAlertActivity.class);
                activity1.startActivity(intent);
            }

            //calculate acclerometer square root
            float accelSqrt = (x*x + y*y + z*z) / (SensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH);
            //
            if (accelSqrt >= accelCompare) {

                textView1.setText(defaultText + accelSqrt);
            }

            X = x;
            Y = y;
            Z = z;
        }
    }

    public void onAccuracyChanged (Sensor sensor, int accuracy)
    {

    }

}
