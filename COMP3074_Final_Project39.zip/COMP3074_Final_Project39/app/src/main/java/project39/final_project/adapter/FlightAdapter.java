package project39.final_project.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import project39.final_project.R;
import project39.final_project.model.Flight;



public class FlightAdapter extends ArrayAdapter{

    private List<Flight> flights;
    private LayoutInflater inflater;

    public FlightAdapter(Context context, int resource, List<Flight> objects) {
        super(context, resource, objects);
       flights=objects;
        inflater=(LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
    }



    public List<Flight> getFlights() {
        return flights;
    }

    public void setFlights(List<Flight> flights) {
        this.flights = flights;
    }

    @Override
    public int getCount() {
        return flights.size();
    }

    @Override
    public Object getItem(int position) {
        return flights.get(position);
    }

    @Override
    public long getItemId(int position) {
        return flights.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view=convertView;
        if(view==null)
            view=inflater.inflate(R.layout.custom_flights_view,null);

        Flight flight=flights.get(position);

        TextView tvAirline=(TextView)view.findViewById(R.id.airline_name);
        TextView tvAirlineCode=(TextView)view.findViewById(R.id.airline_code);
        TextView tvOrigin=(TextView)view.findViewById(R.id.origin_name);
        TextView tvDestination=(TextView)view.findViewById(R.id.destination_name);
        TextView tvDepDate=(TextView)view.findViewById(R.id.dep_date_time);
        TextView tvArrDate=(TextView)view.findViewById(R.id.arr_date_time);
        TextView tvTravelTime=(TextView)view.findViewById(R.id.travel_time_name);
        TextView tvCost=(TextView)view.findViewById(R.id.cost_name);

        tvAirline.setText(flight.getAirline());
        tvAirlineCode.setText(flight.getFlightNum());
        tvOrigin.setText(flight.getOrigin());
        tvDestination.setText(flight.getDestination());
        tvDepDate.setText(flight.getDepartureDateTime());
        tvArrDate.setText(flight.getArrivalDateTime());
        double minute=(flight.getTravelTime()-Math.floor(flight.getTravelTime()))*60;
        int min= (int)minute;
        tvTravelTime.setText(Integer.toString((int)Math.floor(flight.getTravelTime()))+":"+Integer.toString(min));
        tvCost.setText(Double.toString(flight.getCost()));


        return view;
    }
}
