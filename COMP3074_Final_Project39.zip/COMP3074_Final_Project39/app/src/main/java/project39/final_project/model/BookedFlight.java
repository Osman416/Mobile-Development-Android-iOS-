package project39.final_project.model;

/**
 * Created by redsun on 2016-12-10.
 */

public class BookedFlight {

    Client client;
    Flight flight;

    public BookedFlight(Client client, Flight flight) {
        this.client = client;
        this.flight = flight;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }
}
