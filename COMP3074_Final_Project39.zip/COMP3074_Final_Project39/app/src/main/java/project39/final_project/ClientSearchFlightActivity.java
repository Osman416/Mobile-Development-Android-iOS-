package project39.final_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import project39.final_project.database.DatabaseHelper;
import project39.final_project.model.Airline;
import project39.final_project.model.Destination;
import project39.final_project.model.User;

import static android.R.attr.id;
import static project39.final_project.R.string.client_email;

public class ClientSearchFlightActivity extends AppCompatActivity {
    private List<Destination> destinations;
    private DatabaseHelper mDBHelper;
    private ArrayAdapter<String> adapter;
    private int _id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_search_flight);
        setTitle("Search Flights");
        _id=(int)getIntent().getExtras().get("id");
        mDBHelper = new DatabaseHelper(this);
        File database = getApplicationContext().getDatabasePath(DatabaseHelper.DBNAME);
        mDBHelper.getReadableDatabase();
        destinations=mDBHelper.getListDestination();
        List<String> _destinations=new ArrayList<>();
        for(Destination des :destinations)
        _destinations.add(des.get_destination());

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, _destinations);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner sItemDes = (Spinner) findViewById(R.id.search_destination_spinner);
        Spinner sItemOr = (Spinner) findViewById(R.id.search_origin_spinner);
        sItemDes.setAdapter(adapter);
        sItemOr.setAdapter(adapter);
    }

    public void searchFlights(View view) {

        EditText departure_date =
                (EditText) findViewById(R.id.search_departure_date_edit);
//        departure_date.setText("12/20/2016");
        Spinner origin = (Spinner) findViewById(R.id.search_origin_spinner);
//        origin.setSelection(19);
        Spinner destination =
                (Spinner) findViewById(R.id.search_destination_spinner);
//         destination.setSelection(172);
        Intent intent = new Intent(this, ClientDisplayFlightActivity.class);

        intent.putExtra("departure_date", departure_date.getText().toString());
        intent.putExtra("origin", ( mDBHelper.findDestinationId(origin.getSelectedItem().toString())));
        intent.putExtra("destination", mDBHelper.findDestinationId(destination.getSelectedItem().toString()));
        intent.putExtra("userid", _id);
        startActivity(intent);

    }
    public boolean onOptionsItemSelected(MenuItem item) {
        onBackPressed();
        return true;
    }

}
