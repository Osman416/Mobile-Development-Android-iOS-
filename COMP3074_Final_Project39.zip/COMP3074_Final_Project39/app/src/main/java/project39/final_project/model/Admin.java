package project39.final_project.model;

/**
 * Created by redsun on 2016-12-10.
 */

public class Admin extends User {


    public Admin(int id,String lastName, String firstName, String email,  String creditCardNumber, String expiryDate,String password, String isAdmin) {
        super(id,lastName, firstName, email,  creditCardNumber, expiryDate,password, "y");
    }



}
