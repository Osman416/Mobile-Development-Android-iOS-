package project39.final_project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import project39.final_project.database.DatabaseHelper;
import project39.final_project.model.Client;
import project39.final_project.model.Flight;
import project39.final_project.model.User;

import static android.R.attr.name;

public class AdminViewClientActivity extends AppCompatActivity {
    DatabaseHelper mDBHelper;
    List<String> names=new ArrayList<>();
    User client;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_view_client);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("View Client Info");
        mDBHelper = new DatabaseHelper(this);
        File database = getApplicationContext().getDatabasePath(DatabaseHelper.DBNAME);
        mDBHelper.getReadableDatabase();
        names=mDBHelper.getClientNames();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, names);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner sNames = (Spinner) findViewById(R.id.spinner_names);
        sNames.setAdapter(adapter);

        sNames.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
               String name=adapterView.getItemAtPosition(i).toString();
                client=mDBHelper.getClientByName(name.split(" ")[1],name.split(" ")[0]);
                EditText lastname=(EditText)findViewById(R.id.client_last_name_edit);
                EditText firstname=(EditText)findViewById(R.id.client_first_name_edit);
                EditText creditcard=(EditText)findViewById(R.id.client_card_number_edit);
                EditText expirydate=(EditText)findViewById(R.id.client_expiry_edit);
                lastname.setText(name.split(" ")[1]);
                firstname.setText(name.split(" ")[0]);
                creditcard.setText(client.getEmail());
                expirydate.setText(client.getCreditCardNumber());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }





}
