package project39.final_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.File;
import java.util.List;

import project39.final_project.adapter.FlightAdapter;
import project39.final_project.database.DatabaseHelper;
import project39.final_project.model.Destination;
import project39.final_project.model.Flight;

import static project39.final_project.R.string.client;
import static project39.final_project.R.string.origin;

public class ClientBookedItinerariesActivity extends AppCompatActivity {
    private List<Flight> flights;
    private DatabaseHelper mDBHelper;
    private int _id;
    private ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_booked_itineraries);
        setTitle("Booked Itineraries");
        mDBHelper = new DatabaseHelper(this);
        File database = getApplicationContext().getDatabasePath(DatabaseHelper.DBNAME);
        mDBHelper.getReadableDatabase();
        _id=(int)getIntent().getExtras().get("id");
        flights=mDBHelper.getBookedItineraries(_id);
        for(Flight flight:flights)
            Log.v("Search Activity",flight.toString());

        FlightAdapter adapter=new FlightAdapter(this,R.layout.custom_flights_view,flights);
        lv=(ListView)findViewById(R.id.booked_itineraries_listview);
        lv.setAdapter(adapter);

    }
    public void returnHome(View view) {
        Intent intent = new Intent(this, ClientMainActivity.class);
        intent.putExtra("id",_id);
        startActivity(intent);
    }
}
