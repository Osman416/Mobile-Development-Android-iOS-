package project39.final_project.model;

import java.util.ArrayList;

/**
 * Created by redsun on 2016-12-10.
 */

public class Itinerary {

    private ArrayList<Flight> flights;

    public Itinerary(ArrayList<Flight> flights) {
        this.flights = flights;
    }

    public ArrayList<Flight> getFlights() {
        return flights;
    }

    public void setFlights(ArrayList<Flight> flights) {
        this.flights = flights;
    }

    public double getTotalCost() {
        double costs = 0;
        for (Flight flight : flights) {
            costs += flight.getCost();
        }
        return costs;
    }


}
