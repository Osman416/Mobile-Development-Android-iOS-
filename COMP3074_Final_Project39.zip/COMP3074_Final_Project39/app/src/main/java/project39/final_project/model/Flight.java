package project39.final_project.model;
import java.util.Calendar;

import static android.R.id.message;

/**
 * Created by redsun on 2016-12-10.
 */

public class Flight {
    private int id;
    private String flightNum;
    private String departureDateTime;
    private String arrivalDateTime;
    private String airline;
    private String origin;
    private String destination;
    private double travelTime;
    private double cost;
    private String depdate;
    private String deptime;

    public Flight(int id,String flightNum, String departureDateTime, String arrivalDateTime, String airline, String origin, String destination, double cost) {
        this.id=id;
        this.flightNum = flightNum;
        this.departureDateTime = departureDateTime;
        this.arrivalDateTime = arrivalDateTime;
        this.airline = airline;
        this.origin = origin;
        this.destination = destination;
        this.cost = cost;
        this.depdate=date(departureDateTime);
        Calendar depDate = createNewCalendar(departureDateTime);
        Calendar arrDate= createNewCalendar(arrivalDateTime);
        // get the difference in time in milliseconds
        double timeDiff = arrDate.getTimeInMillis()-depDate.getTimeInMillis() ;
        // convert to hours
        this.travelTime = timeDiff/ (1000 * 60 * 60);
        this.deptime=time(departureDateTime);
    }

    public String getDepdate() {
        return depdate;
    }

    public void setDepdate(String depdate) {
        this.depdate = depdate;
    }

    public String getDeptime() {
        return deptime;
    }

    public void setDeptime(String deptime) {
        this.deptime = deptime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getTravelTime() {
        return travelTime;
    }

    public void setTravelTime(double travelTime) {
        this.travelTime = travelTime;
    }

    public String getFlightNum() {
        return flightNum;
    }

    public void setFlightNum(String flightNum) {
        this.flightNum = flightNum;
    }

    public String getDepartureDateTime() {
        return departureDateTime;
    }

    public void setDepartureDateTime(String departureDateTime) {
        this.departureDateTime = departureDateTime;
    }

    public String getArrivalDateTime() {
        return arrivalDateTime;
    }

    public void setArrivalDateTime(String arrivalDateTime) {
        this.arrivalDateTime = arrivalDateTime;
    }

    public String getAirline() {
        return airline;
    }

    public void setAirline(String airline) {
        this.airline = airline;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }


    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    private String date(String date){

        return date.split(" ")[0];
    }
    private String time(String dateTime){

        String time=dateTime.split(" ")[1];
        String ampm=dateTime.split(" ")[2];
        int hour = Integer.valueOf(time.split(":")[0]);
        int min = Integer.valueOf(time.split(":")[1]);
        if(ampm=="PM")
            hour=hour+12;
        return hour+":"+min;
    }
    private Calendar createNewCalendar(String dateTime) {
        // initiate a calendar
        Calendar calendar = Calendar.getInstance();

        // take the given dateandTime string and split it into the different values

        String date=dateTime.split(" ")[0];
        String time=dateTime.split(" ")[1];
        String ampm=dateTime.split(" ")[2];
        int month = Integer.valueOf(date.split("/")[0]);
        int day = Integer.valueOf(date.split("/")[1]);
        int year = Integer.valueOf(date.split("/")[2]);
        int hour = Integer.valueOf(time.split(":")[0]);
        int min = Integer.valueOf(time.split(":")[1]);
        if(ampm=="PM")
            hour=hour+12;
        // set the calendar to the wanted values
        calendar.set(year, month, day, hour, min);
        return calendar;
    }
    @Override
    public String toString() {
      String message = "Flight Number: " + this.getFlightNum() + "\n";
        message += "Departure Date and Time: " + this.getDepartureDateTime() + "\n";
        message += "Arrival Date and Time: " + this.getArrivalDateTime() + "\n";
        message += "Airline: " + this.getAirline() + "\n";
        message += "Origin: " + this.getOrigin() + "\n";
        message += "Destination: " + this.getDestination() + "\n";
        message += "Price: " + String.valueOf(this.getCost()) + "\n";
        return message;
    }
}
