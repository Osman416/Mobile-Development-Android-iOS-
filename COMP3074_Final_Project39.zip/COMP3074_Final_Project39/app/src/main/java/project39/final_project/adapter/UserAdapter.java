package project39.final_project.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.List;

import project39.final_project.model.Admin;
import project39.final_project.model.User;



public class UserAdapter extends BaseAdapter {

    private List<User> user;
    private Context mContext;

    public UserAdapter(List<User> user, Context mContext) {
        this.user= user;
        this.mContext = mContext;
    }



    @Override
    public int getCount() {
        return user.size();
    }

    @Override
    public Object getItem(int position) {
        return user.get(position);
    }

    @Override
    public long getItemId(int position) {
        return user.get(position).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        return null;
    }
}
