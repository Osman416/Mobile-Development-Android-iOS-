package project39.final_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

import project39.final_project.database.DatabaseHelper;
import project39.final_project.model.Client;
import project39.final_project.model.User;

import static project39.final_project.R.string.client;
import static project39.final_project.R.string.client_email;

public class ClientEditProfileActivity extends AppCompatActivity {
    int _id;
    String _email,_lastName,_firstName,_creditcard,_expirydate;
    private DatabaseHelper mDBHelper;
    User user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_edit_profile);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mDBHelper = new DatabaseHelper(this);
        File database = getApplicationContext().getDatabasePath(DatabaseHelper.DBNAME);
        mDBHelper.getReadableDatabase();

        _id=(int)getIntent().getExtras().get("id");
        _email=(String)getIntent().getExtras().get("email");
        _lastName=(String)getIntent().getExtras().get("lastName");
        _firstName=(String)getIntent().getExtras().get("firstName");
        _creditcard=(String)getIntent().getExtras().get("creditcard");
        _expirydate=(String)getIntent().getExtras().get("expirydate");
        setTitle("Edit Profile - "+_firstName);

        ((EditText) findViewById(R.id.client_last_name_edit)).setText(_firstName);
        ((EditText) findViewById(R.id.client_first_name_edit)).setText(_lastName);
        ((EditText) findViewById(R.id.client_card_number_edit)).setText(_creditcard);
        ((EditText) findViewById(R.id.client_expiry_edit)).setText(_expirydate);
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        onBackPressed();
        return true;
    }
    public void submitEditFlightRequest(View view) {

        _lastName=((EditText) findViewById(R.id.client_last_name_edit)).getText().toString();
        _firstName=((EditText) findViewById(R.id.client_first_name_edit)).getText().toString();
        _creditcard=((EditText) findViewById(R.id.client_card_number_edit)).getText().toString();
        _expirydate=((EditText) findViewById(R.id.client_expiry_edit)).getText().toString();
            user = new User(_id, _lastName, _firstName, null, _creditcard, _expirydate, null, null);

            if (mDBHelper.updateUser(user) > 0) {
                Toast.makeText(this, "Your Profile Updated", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this,
                        ClientMainActivity.class);
                intent.putExtra("id",  _id);
                intent.putExtra("email",  _email);
                intent.putExtra("lastName",  _lastName);
                intent.putExtra("firstName",_firstName);
                intent.putExtra("creditcard", _creditcard);
                intent.putExtra("expirydate",_expirydate);
                startActivity(intent);
            }
            else
                Toast.makeText(this, "Your Profile is not Updated, please fill properly!", Toast.LENGTH_SHORT).show();

    }

}
