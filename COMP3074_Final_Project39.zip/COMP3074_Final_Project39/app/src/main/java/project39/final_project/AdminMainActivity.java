package project39.final_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import project39.final_project.model.Flight;

public class AdminMainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Administrator Panel");
        setContentView(R.layout.activity_admin_main);

    }

    public void newFlightsAdd(View view) {
        Intent intent = new Intent(this, AdminNewFlightEnter.class);
        startActivity(intent);
    }

    public void searchClientButton(View view) {
        Intent intent = new Intent(this, AdminViewClientActivity.class);
        startActivity(intent);
    }

    public void logout(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
