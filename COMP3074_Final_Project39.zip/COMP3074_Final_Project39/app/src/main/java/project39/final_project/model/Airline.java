package project39.final_project.model;

/**
 * Created by redsun on 2016-12-11.
 */

public class Airline {

    int id;
    String airline;
    String airlineCode;

    public Airline(int id, String airline, String airlineCode) {
        this.id = id;
        this.airline = airline;
        this.airlineCode = airlineCode;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAirline() {
        return airline;
    }

    public void setAirline(String airline) {
        this.airline = airline;
    }

    public String getAirlineCode() {
        return airlineCode;
    }

    public void setAirlineCode(String airlineCode) {
        this.airlineCode = airlineCode;
    }
}
