package project39.final_project.model;

/**
 * Created by redsun on 2016-12-11.
 */

public class Destination {

    int id;
    String _destination;
    String _airportCode;

    public Destination(int id, String _destination, String _airportCode) {
        this.id = id;
        this._destination = _destination;
        this._airportCode = _airportCode;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String get_destination() {
        return _destination;
    }

    public void set_destination(String _destination) {
        this._destination = _destination;
    }

    public String get_airportCode() {
        return _airportCode;
    }

    public void set_airportCode(String _airportCode) {
        this._airportCode = _airportCode;
    }
}
