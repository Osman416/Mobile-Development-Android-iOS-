package project39.final_project;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.List;

import project39.final_project.adapter.UserAdapter;
import project39.final_project.database.DatabaseHelper;
import project39.final_project.model.User;

public class MainActivity extends AppCompatActivity {

//    private UserAdapter userAdapter;
    private List<User> users;
    private DatabaseHelper mDBHelper;
    boolean found;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDBHelper = new DatabaseHelper(this);
        File database = getApplicationContext().getDatabasePath(DatabaseHelper.DBNAME);
        if(false == database.exists()) {
            mDBHelper.getReadableDatabase();
            //Copy db
            if(mDBHelper.copyDatabase(this)) {
                Toast.makeText(this, "succes", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "data error", Toast.LENGTH_SHORT).show();
                return;
            }
        }
    }

    public void checkLogin(View view) {
        users=mDBHelper.getListUser();
        found=false;

                EditText username = (EditText) findViewById(R.id.
                        username_edit_text);
//        username.setText("karasu@gmail.com");
                EditText password = (EditText) findViewById(R.id.
                        password_edit_text);
//password.setText("1111");
                for(User fUser : users)
                {

                    if(username.getText().toString().equals(fUser.getEmail())&&password.getText().toString().equals(fUser.getPassword())){
                        found=true;
                        Log.w("MainActivity","he is admin:"+fUser.getIsAdmin());
                        if(fUser.getIsAdmin().equals("y")){
                            Log.w("MainActivity","he is admin");
                             Intent intent = new Intent(this,
                                     AdminMainActivity.class);
                            intent.putExtra("id",  fUser.getId());
                            intent.putExtra("email",  fUser.getEmail());
                            intent.putExtra("lastName",  fUser.getLastName());
                            intent.putExtra("firstName",fUser.getFirstName());
                            intent.putExtra("creditcard",  fUser.getCreditCardNumber());
                            intent.putExtra("expirydate",fUser.getExpiryDate());


                            startActivity(intent);}
                        else{
                             Intent intent = new Intent(this,
                                     ClientMainActivity.class);
                            intent.putExtra("id",  fUser.getId());
                            intent.putExtra("email",  fUser.getEmail());
                            intent.putExtra("lastName",  fUser.getLastName());
                            intent.putExtra("firstName",fUser.getFirstName());
                            intent.putExtra("creditcard",  fUser.getCreditCardNumber());
                            intent.putExtra("expirydate",fUser.getExpiryDate());
                             startActivity(intent);


                         }
                    }


                }
        if(!found)
        alert("Sorry", "Username or password not found.", this);

//        }
    }
    public static void alert(String title, String message, Activity activity) {
        AlertDialog loginFailDialog =
                new AlertDialog.Builder(activity).create();
        loginFailDialog.setTitle(title);
        loginFailDialog.setMessage(message);
        loginFailDialog.setButton(AlertDialog.BUTTON_NEUTRAL,
                "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        loginFailDialog.show();
    }



}
