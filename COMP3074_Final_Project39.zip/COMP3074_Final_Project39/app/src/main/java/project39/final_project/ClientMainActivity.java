package project39.final_project;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.io.Serializable;

import project39.final_project.model.Itinerary;
import project39.final_project.model.User;

import static android.R.attr.id;
import static project39.final_project.R.string.client_email;

public class ClientMainActivity extends AppCompatActivity {
    int _id;
    String _email,_lastName,_firstName,_creditcard,_expirydate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_main);
        setTitle("Client");
        _id=(int)getIntent().getExtras().get("id");
        _email=(String)getIntent().getExtras().get("email");
        _lastName=(String)getIntent().getExtras().get("lastName");
        _firstName=(String)getIntent().getExtras().get("firstName");
        _creditcard=(String)getIntent().getExtras().get("creditcard");
        _expirydate=(String)getIntent().getExtras().get("expirydate");



    }
    public void searchFlights(View view) {
        Intent intent = new Intent(this, ClientSearchFlightActivity.class);
        intent.putExtra("id",  _id);
        intent.putExtra("email",  _email);
        intent.putExtra("lastName",  _lastName);
        intent.putExtra("firstName",_firstName);
        intent.putExtra("creditcard",  _creditcard);
        intent.putExtra("expirydate",_expirydate);
        startActivity(intent);

    }

    public void bookedItineraries(View view) {
        Intent intent = new Intent(this, ClientBookedItinerariesActivity.class);
        Log.v("viewBookedItineraries","id="+_id);
        intent.putExtra("id", _id);
        startActivity(intent);
    }

    public void editClientInfo(View view) {
        Intent intent = new Intent(this, ClientEditProfileActivity.class);
        intent.putExtra("id",  _id);
        intent.putExtra("email",  _email);
        intent.putExtra("lastName",  _lastName);
        intent.putExtra("firstName",_firstName);
        intent.putExtra("creditcard",  _creditcard);
        intent.putExtra("expirydate",_expirydate);
        startActivity(intent);

    }
    public void logout(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


}
