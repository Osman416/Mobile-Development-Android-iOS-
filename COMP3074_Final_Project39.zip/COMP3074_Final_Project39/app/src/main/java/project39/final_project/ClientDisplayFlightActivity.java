package project39.final_project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import project39.final_project.R;
import project39.final_project.adapter.FlightAdapter;
import project39.final_project.database.DatabaseHelper;
import project39.final_project.model.Flight;

public class ClientDisplayFlightActivity extends AppCompatActivity {
    int departure,origin,id,selectedId;
    String date;
    DatabaseHelper mDBHelper;
    List<Flight> flights=new ArrayList<>();
    Flight selectedFlight;

    private ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_display_flight);
        setTitle("Display Flights");
        mDBHelper = new DatabaseHelper(this);
        File database = getApplicationContext().getDatabasePath(DatabaseHelper.DBNAME);
        mDBHelper.getReadableDatabase();

        id = (int) getIntent().getExtras().get("userid");
        departure = (int) getIntent().getExtras().get("destination");
        origin = (int) getIntent().getExtras().get("origin");
        date = (String) getIntent().getExtras().get("departure_date");
        Log.w("MainActivity", "id: " + id + " ,dep: " + departure + " ,ori: " + origin + " ,date: " + date);
        flights=mDBHelper.findFlight(origin, departure, date);
        for(Flight flight:flights)
             Log.v("Search Activity",flight.toString());

        FlightAdapter adapter=new FlightAdapter(this,R.layout.custom_flights_view,flights);
        lv=(ListView)findViewById(R.id.flight_list);
        lv.setAdapter(adapter);

        // Set a listener for when a user selects a flight.
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                selectedFlight = (Flight) parent.getItemAtPosition(position);
                selectedId=selectedFlight.getId();
                Toast.makeText(getApplicationContext(),
                        "Flight number " + selectedFlight.getFlightNum()
                                + " selected-id:"+id, Toast.LENGTH_LONG)
                        .show();
            }
        });


    }

    public void bookFlight(View view) {
            if(selectedFlight!=null){
                if(mDBHelper.addItinerary(id,selectedId)>0)
                {Toast.makeText(getApplicationContext(),
                            "Selected Itinerary added successfully ", Toast.LENGTH_SHORT)
                            .show();}

            }
            else{
                Toast.makeText(getApplicationContext(),
                        "For booking, Please select an Itinerary ", Toast.LENGTH_SHORT)
                        .show();
            }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        onBackPressed();
        return true;
    }
    public void sortByCost(View view) {

        Collections.sort(flights, new Comparator<Flight>() {
            @Override
            public int compare(Flight c1, Flight c2) {
                return Double.compare(c1.getCost(), c2.getCost());
            }
        });
        FlightAdapter adapter=new FlightAdapter(this,R.layout.custom_flights_view,flights);
        lv=(ListView)findViewById(R.id.flight_list);
        lv.setAdapter(adapter);
//        lv.notifyAll();

    }

    public void sortByTime(View view) {

        Collections.sort(flights, new Comparator<Flight>() {
            @Override
            public int compare(Flight c1, Flight c2) {
                return c1.getDeptime().compareTo(c2.getDeptime());
            }
        });
        FlightAdapter adapter=new FlightAdapter(this,R.layout.custom_flights_view,flights);
        lv=(ListView)findViewById(R.id.flight_list);
        lv.setAdapter(adapter);
//        lv.notifyAll();

    }





}
