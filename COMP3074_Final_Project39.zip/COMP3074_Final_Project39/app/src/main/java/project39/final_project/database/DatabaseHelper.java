package project39.final_project.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import project39.final_project.model.Airline;
import project39.final_project.model.Client;
import project39.final_project.model.Destination;
import project39.final_project.model.Flight;
import project39.final_project.model.User;

import static android.R.attr.id;
import static android.R.attr.lines;
import static android.R.attr.theme;
import static android.R.attr.version;
import static android.icu.lang.UCharacter.JoiningGroup.E;
import static project39.final_project.R.string.destination;
import static project39.final_project.R.string.origin;



public class DatabaseHelper extends SQLiteOpenHelper {


    public static  final String DBNAME="COMP3074_Final_Project39.sqlite";
    public static  final String DBLOCATION="/data/data/project39.final_project/databases/";
    private Context mContext;
    private SQLiteDatabase mDatabase;


    public DatabaseHelper(Context context) {
        super(context, DBNAME, null, 1);
        this.mContext=context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void openDatabase(){

        String dbPath=mContext.getDatabasePath(DBNAME).getPath();
        if(mDatabase!=null&&mDatabase.isOpen())
            return;
        mDatabase=SQLiteDatabase.openDatabase(dbPath,null,SQLiteDatabase.OPEN_READWRITE);
    }

    public void closeDatabase(){

        if(mDatabase!=null)
            mDatabase.close();
    }

    public List<Flight> getListFlight(){

        Flight flight=null;
        List<Flight> flights=new ArrayList<>();
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM FLIGHT",null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            flight=new Flight(cursor.getInt(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6),cursor.getDouble(7));
            flights.add(flight);
            cursor.moveToNext();
        }
        cursor.close();
        closeDatabase();
        return flights;

    }

    public long addItinerary(int userid,int flightid){

        ContentValues contentValues = new ContentValues();
        contentValues.put("userid", userid);
        contentValues.put("flightid", flightid);
        openDatabase();
        long returnValue = mDatabase.insert("bookedflights", null, contentValues);
        closeDatabase();
        return returnValue;

    }



    public List<Flight> getBookedItineraries(int id){
        Flight flight;
        List<Flight> flights=new ArrayList<>();
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM bookedflights WHERE userid=?",new String[]{String.valueOf(id)});
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            Log.v("findflightbyid","flightid :"+cursor.getInt(1));
            flight=findFlightById(cursor.getInt(1));

            flights.add(flight);
            Log.v("findflightbyid",flight.toString());
            cursor.moveToNext();
        }
        cursor.close();
        closeDatabase();
        return flights;

    }

    public Flight findFlightById(int id){
        Flight flight=null;
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM flight WHERE fligtid=?",new String[]{String.valueOf(id)});
        cursor.moveToFirst();
        if( cursor != null && cursor.moveToFirst() ){
            String airline=getAirlineName(cursor.getInt(4));
            String _origin=getDestinationName(cursor.getInt(5));
            String _destination=getDestinationName(cursor.getInt(6));
            flight=new Flight(cursor.getInt(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),airline,_origin,_destination,cursor.getDouble(7));
            cursor.close();}
        Log.v("findflightbyid",flight.toString());
        closeDatabase();
        return flight;

    }





    public List<Destination> getListDestination(){

        Destination destination=null;
        List<Destination> destinations=new ArrayList<>();
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM destinations",null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            destination=new Destination(cursor.getInt(0),cursor.getString(1),cursor.getString(1));
            destinations.add(destination);
            cursor.moveToNext();
        }
        cursor.close();
        closeDatabase();
        return destinations;

    }

    public List<Airline> getListAirline(){

        Airline airline=null;
        List<Airline> airlines=new ArrayList<>();
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM airlines",null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            airline=new Airline(cursor.getInt(0),cursor.getString(1),cursor.getString(1));
            airlines.add(airline);
            cursor.moveToNext();
        }
        cursor.close();
        closeDatabase();
        return airlines;

    }
    public int findAirlineId(String airline){
        int id=-1;
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM airlines WHERE airline=?",new String[]{airline});
        Log.w("MainActivity","Id number "+id);
        cursor.moveToFirst();
        id=cursor.getInt(0);
        cursor.close();
        closeDatabase();
        return id;

    }

    public String getAirlineName(int id){
        String airline=null;
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM airlines WHERE airlinesid=?",new String[]{String.valueOf(id)});
        if( cursor != null && cursor.moveToFirst() ){
        airline=cursor.getString(1);
        cursor.close();}
        closeDatabase();
        return airline;
    }

    public int findDestinationId(String destination){
        int id=-1;
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM destinations WHERE destination=?",new String[]{destination});
        Log.w("MainActivity","Id number "+id);
        cursor.moveToFirst();
        id=cursor.getInt(0);
        cursor.close();
        closeDatabase();
        return id;

    }

    public String getDestinationName(int id){
        String destination=null;
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM destinations WHERE destinationid=?",new String[]{String.valueOf(id)});
        if( cursor != null && cursor.moveToFirst() ){
        destination=cursor.getString(1);
        cursor.close();}
        closeDatabase();
        return destination;
    }

    public List<Flight> findFlight(int origin,int destination,String date){
        Flight _flight;
        List<Flight> _flights=new ArrayList<>();
        openDatabase();
        String query="select * from flight where origin=? and destination=?";
        Cursor cursor=mDatabase.rawQuery(query, new String[]{String.valueOf(origin),String.valueOf(destination)});
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            String airline=getAirlineName(cursor.getInt(4));
            String _origin=getDestinationName(cursor.getInt(5));
            String _destination=getDestinationName(cursor.getInt(6));
            _flight=new Flight(cursor.getInt(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),airline,_origin,_destination,cursor.getDouble(7));
           if(_flight.getDepdate().equals(date.trim()))
               _flights.add(_flight);
            Log.w("MainActivity", "list size:"+_flights.size()+" id: " + _flight.getId() + " ,dep: " + _flight.getDepdate() + " ,ori: " + _flight.getOrigin()+ " ,des: " + _flight.getDestination()+
                    " ,airline: " + _flight.getAirline()+ " ,cost: " + _flight.getCost());
            cursor.moveToNext();
        }
        cursor.close();
        closeDatabase();
        return _flights;
    }

    public List<User> getListUser(){

        User user=null;
        List<User> users=new ArrayList<>();
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM USER",null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            user=new User(cursor.getInt(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6),cursor.getString(7));
            users.add(user);
            cursor.moveToNext();
        }
        cursor.close();
        closeDatabase();
        return users;

    }

    public List<String> getClientNames(){
        String name=null;
        List<String> names=new ArrayList<>();
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM USER",null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            name=cursor.getString(1)+" "+cursor.getString(2);
            names.add(name);
            cursor.moveToNext();
        }
        cursor.close();
        closeDatabase();
        return names;
    }

    public  User getClientByName(String fname,String lname){

       User client=null;
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM user WHERE lastname=? AND firstname=?",new String[]{lname,fname});
        if( cursor != null && cursor.moveToFirst() ){
            client=new Client(cursor.getInt(0),cursor.getString(1),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6),cursor.getString(7),"n");
            cursor.close();}
        closeDatabase();
        return client;


    }


    public long addFlight(Flight flight){

        ContentValues contentValues = new ContentValues();
        contentValues.put("flightnum", flight.getFlightNum());
        contentValues.put("depdatetime", flight.getDepartureDateTime());
        contentValues.put("arrdatetime", flight.getArrivalDateTime());
        contentValues.put("airline", findAirlineId(flight.getAirline()));
        contentValues.put("origin",  findDestinationId(flight.getOrigin()));
        contentValues.put("destination", findDestinationId(flight.getDestination()));
        contentValues.put("cost", flight.getCost());
        openDatabase();
        long returnValue = mDatabase.insert("flight", null, contentValues);

        closeDatabase();
        return returnValue;

    }
    public long updateUser(User user) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("firstname", user.getFirstName());
        contentValues.put("lastname",user.getLastName());
        contentValues.put("creditcardnum", user.getCreditCardNumber());
        contentValues.put("expirydate", user.getExpiryDate());
//        contentValues.put("email", user.getEmail());
        String[] whereArgs = {Integer.toString(user.getId())};
        openDatabase();
        long returnValue = mDatabase.update("user",contentValues, "userid=?", whereArgs);

        closeDatabase();

        return returnValue;
    }

    public boolean copyDatabase(Context context){
        try {

            InputStream inputStream = context.getAssets().open(DatabaseHelper.DBNAME);
            String outFileName = DatabaseHelper.DBLOCATION + DatabaseHelper.DBNAME;
            OutputStream outputStream = new FileOutputStream(outFileName);
            byte[]buff = new byte[1024];
            int length = 0;
            while ((length = inputStream.read(buff)) > 0) {
                outputStream.write(buff, 0, length);
            }
            outputStream.flush();
            outputStream.close();
            Log.w("MainActivity","DB copied");
            return true;
        }catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }




}
