package project39.final_project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import project39.final_project.database.DatabaseHelper;
import project39.final_project.model.Airline;
import project39.final_project.model.Destination;
import project39.final_project.model.Flight;

import static project39.final_project.R.string.destination;
import static project39.final_project.R.string.origin;

public class AdminNewFlightEnter extends AppCompatActivity {
    private DatabaseHelper mDBHelper;
    private Flight flight=null;
    private EditText flight_departure;
    private EditText flight_arrival;
    private Spinner flight_airline;
    private Spinner flight_origin;
    private Spinner flight_destination;
    private EditText flight_cost;
    private EditText flight_num;
    private List<Destination> destinations;
    private List<Airline> airlines;
    private ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_new_flight_enter);
        setTitle("New Flight");
        mDBHelper = new DatabaseHelper(this);
        File database = getApplicationContext().getDatabasePath(DatabaseHelper.DBNAME);
        mDBHelper.getWritableDatabase();
        destinations=mDBHelper.getListDestination();
        airlines=mDBHelper.getListAirline();
        List<String> _destinations=new ArrayList<>();
        for(Destination des :destinations)
            _destinations.add(des.get_destination());

        List<String> _airlines=new ArrayList<>();
        for(Airline air :airlines)
            _airlines.add(air.getAirline());

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, _destinations);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, _airlines);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner sItemDes = (Spinner) findViewById(R.id.destination_new);
        Spinner sItemOr = (Spinner) findViewById(R.id.origin_new);
        Spinner airspin=(Spinner)findViewById(R.id.airline_new);
        sItemDes.setAdapter(adapter);
        sItemOr.setAdapter(adapter);
        airspin.setAdapter(adapter1);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        onBackPressed();
        return true;
    }

    public  void submitNewFlightData(View view){


        flight_num =
        (EditText) findViewById(R.id.flight_num);
        flight_departure =
                (EditText) findViewById(R.id.departure_date_edit);
        flight_arrival =
                (EditText) findViewById(R.id.arrival_date_edit);
        flight_airline =
                (Spinner) findViewById(R.id.airline_new);
        flight_origin =
                (Spinner) findViewById(R.id.origin_new);
        flight_destination =
                (Spinner) findViewById(R.id.destination_new);
        flight_cost =
                (EditText) findViewById(R.id.cost_edit);
       flight=new Flight(0,flight_num.getText().toString(),flight_departure.getText().toString(),
               flight_arrival.getText().toString(), flight_airline.getSelectedItem().toString(),flight_origin.getSelectedItem().toString(),
               flight_destination.getSelectedItem().toString(),Double.parseDouble(flight_cost.getText().toString()));
        if(mDBHelper.addFlight(flight)>0)
            Toast.makeText(this, "flight added", Toast.LENGTH_SHORT).show();
     else
        Toast.makeText(this, "please try again", Toast.LENGTH_SHORT).show();




    }


}
