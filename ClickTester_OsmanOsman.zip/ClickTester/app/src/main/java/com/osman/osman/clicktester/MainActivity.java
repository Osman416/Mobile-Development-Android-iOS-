package com.osman.osman.clicktester;



import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {

    // method to know what was clicked by user
    private String whichWidget(View v){
        String which = "";

        // switch cases:
        switch(v.getId()){
            case R.id.button1:
                which = getString(R.string.buttonString);
                break;
            case R.id.redblock:
                which = getString(R.string.redString);
                break;
            case R.id.greenblock:
                which = getString(R.string.greenString);
                break;
            case R.id.yellowblock:
                which = getString(R.string.yellowString);
                break;
            case R.id.blueblock:
                which = getString(R.string.blueString);
                break;
        }
        return which;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View view;

        // short click & long click listeners

        View button1 = findViewById(R.id.button1);
        button1.setOnClickListener(this);
        button1.setOnLongClickListener(this);

        View redblock = findViewById(R.id.redblock);
        redblock.setOnClickListener(this);
        redblock.setOnLongClickListener(this);

        View greenblock = findViewById(R.id.greenblock);
        greenblock.setOnClickListener(this);
        greenblock.setOnLongClickListener(this);

        View yellowblock = findViewById(R.id.yellowblock);
        yellowblock.setOnClickListener(this);
        yellowblock.setOnLongClickListener(this);

        View blueblock = findViewById(R.id.blueblock);
        blueblock.setOnClickListener(this);
        blueblock.setOnLongClickListener(this);
    }

    // Handling long clicks
    @Override
    public boolean onLongClick(View v) {
        String which = whichWidget(v);
        // if it wasn't the button that was clicked by user (long click)
        if(which != getString(R.string.buttonString)){
            whichWidget(v);
            // if button is clicked (long click)
        } else {
            Toast.makeText(this, getString(R.string.longclick) +" "+ which,
                    Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    // Handling short clicks
    @Override
    public void onClick(View v) {
        String which = whichWidget(v);
        if(which != getString(R.string.buttonString)){
            Toast.makeText(this, getString(R.string.shortclick) + " "+which,
                    Toast.LENGTH_SHORT).show();
        } else { // close application when button is clicked (short click)
            finish();
            System.exit(0);
        }

    }

}